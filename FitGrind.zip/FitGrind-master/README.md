# FitGrind

Tracking your personal fitness goals, and achieving them.

## Installing

Launch Android Studio, and install the APK.

## Libraries

We have used the following libraries:

* Fast Android Networking
* Picasso
* CircleIndicator
* USDA API
* Android's RecyclerView, and CardView
